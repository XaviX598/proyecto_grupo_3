<template>
    <div class="container">
        <p>Copyright © 2023 - Grupo 3 Programación Web</p>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.container {
    text-align: center;
    background: #A68D37;
    padding: 10px;
}

p {
    margin: 0px;
    font-size: 2.1vh;
}
</style>