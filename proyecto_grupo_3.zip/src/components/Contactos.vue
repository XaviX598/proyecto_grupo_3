<template>
  <div class="container">
    <div>
      <h1>Contacto</h1>
      <p>Cdla. Universitaria</p>
      <p>
        <font-awesome-icon icon="fa-solid fa-location-dot" style="color: #ffffff" />
        Dirección: Gaspar de Carvajal y Gilberto Gato Sobral,
        RF2W+RPQ, Quito 170521
      </p>
      <p>
        <font-awesome-icon icon="fa-solid fa-square-phone" /> Teléfono : 022542026
      </p>

      <p>
        Correo electrónico :
        <a href="mailto:prmentoruce@gmail.com">prmentoruce@gmail.com</a>
      </p>

      <p>Redes sociales</p>
      <a href="https://www.facebook.com/profile.php?id=61550039305560&mibextid=ZbWKwL">
        <font-awesome-icon icon="fa-brands fa-facebook" />
      </a>
      <a href="https://instagram.com/prmentor?utm_source=qr&igshid=ZDc4ODBmNjlmNQ%3D%3D">
        <font-awesome-icon icon="fa-brands fa-instagram" />
      </a>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
h2 {
  font-size: 18px;
  text-decoration: none;
  font-weight: bold;
  color: black;
}

.container {
  background: #017DC7;
  width: 100%;
  border-top: 2px solid #00395a;
}

p {
  margin: 0PX;
}
</style>