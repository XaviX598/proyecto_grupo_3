<template>
  <h1>Bienvenidos</h1>
  <Banner />
</template>

<script>
import Banner from "../components/Banner.vue";
export default {
  components: {
    Banner,
  },
};
</script>

<style scoped>
</style>